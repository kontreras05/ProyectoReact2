
export interface FormData {
  nombre: string;
  email: string;
  telefono: string;
  direccion: string;
  ciudad: string;
  codigoPostal: string;
  tipoEntrenamiento: string;
  objetivos: string;
  disponibilidad: string[];
}
